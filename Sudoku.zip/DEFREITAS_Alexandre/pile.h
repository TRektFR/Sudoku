#include <stdio.h>
#include <stdlib.h>


#define NMAX 1000

struct Pile{
  int x[NMAX];
  int y[NMAX];
  int som;
};
typedef struct Pile Pile;


Pile creer_pile();

int est_vide(Pile p);

Pile push(Pile p, int i, int j);

Pile pop(Pile p);

int picky(Pile p);

int pickx(Pile p);

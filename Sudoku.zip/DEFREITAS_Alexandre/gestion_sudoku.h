
#ifndef __SUDOKU_H
#define __SUDOKU_H



struct Case  {
	
	int val;//valeur d'une case
	int p[9];  //valeur potentiel d'une case
	int w;  //case de travail 1 ou case de depart 0
};
typedef struct Case CASE;


struct sudoku {
	CASE T[9][9]; //tableau de case
	char* nom;    //nom du sudoku
	int num;      //numero de la sauvegarde
};

typedef struct sudoku SUDOKU;


// enleve les valeur impossible ne laissant que celle étant possible 
//dans le tableau de valeurs possible dans la case [i][j]
SUDOKU valeur_possible(SUDOKU S,int i, int j);

// applique valeur_possible a tout le sudoku
SUDOKU tout_val_poss(SUDOKU S);

// initialise le sudoku
SUDOKU init_sudoku(SUDOKU S);

// change la valeur d'une case 
SUDOKU modifie_case(SUDOKU S, int i, int j);

// change la valeur d'une case en allant en priorité vers une valeur inférieur
SUDOKU modifie_case_inverse(SUDOKU S, int i, int j);

// verifie que la case i,j peut prendre la valeur val
int val_est_possible(SUDOKU S,int i, int j,int val);


// renvoie le nombre de valeur possible d'une case 
// si aucune n'est possible renvoie 0
int case_est_possible(SUDOKU S,int i, int j);

// renvoie si le sudoku est possible ou non
int sudoku_est_possible(SUDOKU S);



#endif


#include <stdlib.h>
#include "uvsqgraphics.h"
#include "constantes.h"
#include "afficher.h"
#include "gestion_sudoku.h"
#include "lire_ecrire.h"
#include "pile.h"



// fonction quittant le sudoku en affichant l'ecran de victoire
void sudoku_quit(){
	
	wait_escape();
	afficher_win();
	terminer_fenetre_graphique();
	exit(0);
}


// undo utilisant une pile
SUDOKU undo(SUDOKU S, Pile* p){
	
	int i,j;
	
	
	
	i = pickx(*p);
	j = picky(*p);
	S = modifie_case_inverse(S,i,j);
	
	*p = pop(*p);
	
	return S;
	
}

// fonction de sauvegarde
SUDOKU sudoku_sauv(SUDOKU S){
	
	ecrire_fichier(&S);
	S = lire_fichier(S.nom);
	return S;
}

// verifie si le sudoku a encore des case vide
int sudoku_verif(SUDOKU S){
	
	int i,j;
	
	for(i = 0; i < 9; i++){
		for(j = 0; j < 9; j++){
			if(S.T[i][j].val == 0) return 0;
		}
	}
	return 1;
}

SUDOKU resolve_1_poss_min(SUDOKU S){
	int i,j;
	for(i = 0; i < 9; i++){
		for(j = 0; j < 9; j++){
			if(case_est_possible(S,i,j) == 1){
				if(S.T[i][j].val == 0){
					S = modifie_case(S,i,j);
					S = init_sudoku(S);
				}
			}
		}
	}
	
	return S;
}




// renvoie le nombre de possibilté minimum
int nbres_poss_min(SUDOKU S){
	int i,j, min;
	min = 9;
	for(i = 0; i < 9; i++){
		for(j = 0; j < 9; j++){
			if(case_est_possible(S,i,j) < min && case_est_possible(S,i,j) != 0) min = case_est_possible(S,i,j);
		}
	}
	return min;
}


// fonction recursive de resolution du sudoku
int resolve_sudoku(SUDOKU S){
	int i,j,v;
	
	
	// verifie que si le sudoku est terminé ou non
	if(sudoku_verif(S) == 1){
		sudoku_afficher(S);
		return 1;
	}
	for(j = 0; j < 9; j++){
		for(i = 0; i < 9; i++){
			if(S.T[i][j].val == 0 ){
				for(v=1;v<= 9;v++){
					if( val_est_possible(S,i,j,v)){
					S.T[i][j].val = v;
					S.T[i][j].w = 2;
					S = init_sudoku(S);
					
					
					if(resolve_sudoku(S)) return 1;
					
					S.T[i][j].val = 0;
					S.T[i][j].w = 1;
					S = init_sudoku(S);
					
					}
				}
			//active la récursion
			return 0;
			}
		}
	}
	return 0; //permet de dire si oui ou non la resolution est possible
}

// utilise le resultat de la resolution
void resolve(SUDOKU S){
	if(resolve_sudoku(S) == 1){
		sudoku_quit();
	
	}
	printf("pas de solution possible\n");
	exit(0);
	}



SUDOKU jouer(SUDOKU S,Pile* P){
	POINT p;
	int i,j;
	char c;
	
	c = -1;
	p.x = -1;
	p.y = -1;

	 
	
	wait_key_arrow_clic(&c,&i,&p);
	
	
	
	if(c != -1 ){
		if(c == 'U') S = undo(S,P);
		if(c == 'V') resolve(S);
		if(c == 'S') S = sudoku_sauv(S);
		if(c == 'Q') exit(0);
		
	}
	
	if(p.x != -1 && p.y != -1){
		if(p.x > LARGEUR || p.y > (TAILLE_CASE*9)){
			printf("veuillez cliqué sur une case du sudoku\n");
		}
		i = (p.x/TAILLE_CASE);
		j = 8-(p.y/TAILLE_CASE);
		S = modifie_case(S,i,j);
		sudoku_afficher(S);
		if(S.T[i][j].w == 1){
			*P = push(*P,i,j);
		}
	}
	S = init_sudoku(S);
	
	

	return S;
}



int main (int argc, char *argv[]) {
	
    SUDOKU S;
    Pile p;
    p = creer_pile();
    S = lire_fichier(argv[1]);
    initialiser_fenetre_graphique();
    sudoku_afficher(S);
   
    
    while (sudoku_verif(S) == 0) {
        S = jouer(S,&p);
        sudoku_afficher(S);
    }
    afficher_win();
    terminer_fenetre_graphique();
    exit(0);
}

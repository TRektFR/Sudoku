#include "gestion_sudoku.h"

#ifndef __AFFICHER_H
#define __AFFICHER_H
// Fonction a appeler au début pour créer la fenêtre grapĥique
void initialiser_fenetre_graphique();

// Fonction a appeler à la fin pour terminer proprement la fenêtre grapĥique
void terminer_fenetre_graphique();

// Fonction qui affiche la grille du sudoku
void afficher_grille();

// met en evidence les regions du sudoku 
void afficher_region();

// affiche le titre du sudoku
void afficher_titre(SUDOKU S);

// affiche les numéros des case
// la couleur est differente si c'est un
// nombre de travail, de depart ou trouver grace a la resolution
void afficher_nbres(SUDOKU S);

// affiche les nombre possible sur les cases
void afficher_poss(SUDOKU S);

// affiche l'ecran de victoire
void afficher_win();

// Fonction qui affiche l'état courant du sudoku
void sudoku_afficher(SUDOKU S);
#endif

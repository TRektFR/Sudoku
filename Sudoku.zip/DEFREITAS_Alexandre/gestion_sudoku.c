#include <stdlib.h>
#include <stdio.h>
#include "gestion_sudoku.h"



SUDOKU valeur_possible(SUDOKU S,int i, int j){
	
	int e,val;
	
	for(e=0;e<9;e++){
		if(e != i){
			val = S.T[e][j].val;
			if(val > 0) S.T[i][j].p[val-1] = 0;
		}
	}
	for(e=0;e<9;e++){
		if(e != j){
			val = S.T[i][e].val;
			if(val > 0) S.T[i][j].p[val-1] = 0;
		}
	}
	if(i%3 == 0){
		if(j%3 == 0){
			if(S.T[i+1][j+1].val > 0) S.T[i][j].p[(S.T[i+1][j+1].val)-1] = 0;
			if(S.T[i+2][j+1].val > 0) S.T[i][j].p[(S.T[i+2][j+1].val)-1] = 0;
			if(S.T[i+1][j+2].val > 0) S.T[i][j].p[(S.T[i+1][j+2].val)-1] = 0;
			if(S.T[i+2][j+2].val > 0) S.T[i][j].p[(S.T[i+2][j+2].val)-1] = 0;
		}
		if(j%3 == 1){
			if(S.T[i+1][j-1].val > 0) S.T[i][j].p[(S.T[i+1][j-1].val)-1] = 0;
			if(S.T[i+2][j-1].val > 0) S.T[i][j].p[(S.T[i+2][j-1].val)-1] = 0;
			if(S.T[i+1][j+1].val > 0) S.T[i][j].p[(S.T[i+1][j+1].val)-1] = 0;
			if(S.T[i+2][j+1].val > 0) S.T[i][j].p[(S.T[i+2][j+1].val)-1] = 0;
		}
		if(j%3 == 2){
			if(S.T[i+1][j-1].val > 0) S.T[i][j].p[(S.T[i+1][j-1].val)-1] = 0;
			if(S.T[i+2][j-1].val > 0) S.T[i][j].p[(S.T[i+2][j-1].val)-1] = 0;
			if(S.T[i+1][j-2].val > 0) S.T[i][j].p[(S.T[i+1][j-2].val)-1] = 0;
			if(S.T[i+2][j-2].val > 0) S.T[i][j].p[(S.T[i+2][j-2].val)-1] = 0;
		}
			
	}
	if(i%3 == 1){
		if(j%3 == 0){
			if(S.T[i+1][j+1].val > 0) S.T[i][j].p[(S.T[i+1][j+1].val)-1] = 0;
			if(S.T[i+1][j+2].val > 0) S.T[i][j].p[(S.T[i+1][j+2].val)-1] = 0;
			if(S.T[i-1][j+1].val > 0) S.T[i][j].p[(S.T[i-1][j+1].val)-1] = 0;
			if(S.T[i-1][j+2].val > 0) S.T[i][j].p[(S.T[i-1][j+2].val)-1] = 0;
		}
		if(j%3 == 1){
			if(S.T[i+1][j+1].val > 0) S.T[i][j].p[(S.T[i+1][j+1].val)-1] = 0;
			if(S.T[i+1][j-1].val > 0) S.T[i][j].p[(S.T[i+1][j-1].val)-1] = 0;
			if(S.T[i-1][j+1].val > 0) S.T[i][j].p[(S.T[i-1][j+1].val)-1] = 0;
			if(S.T[i-1][j-1].val > 0) S.T[i][j].p[(S.T[i-1][j-1].val)-1] = 0;
		}
		if(j%3 == 2){
			if(S.T[i+1][j-1].val > 0) S.T[i][j].p[(S.T[i+1][j-1].val)-1] = 0;
			if(S.T[i+1][j-2].val > 0) S.T[i][j].p[(S.T[i+1][j-2].val)-1] = 0;
			if(S.T[i-1][j-1].val > 0) S.T[i][j].p[(S.T[i-1][j-1].val)-1] = 0;
			if(S.T[i-1][j-2].val > 0) S.T[i][j].p[(S.T[i-1][j-2].val)-1] = 0;
		}
	}
	if(i%3 == 2){
		if(j%3 == 0){
			if(S.T[i-1][j+1].val > 0) S.T[i][j].p[(S.T[i-1][j+1].val)-1] = 0;
			if(S.T[i-2][j+1].val > 0) S.T[i][j].p[(S.T[i-2][j+1].val)-1] = 0;
			if(S.T[i-1][j+2].val > 0) S.T[i][j].p[(S.T[i-1][j+2].val)-1] = 0;
			if(S.T[i-2][j+2].val > 0) S.T[i][j].p[(S.T[i-2][j+2].val)-1] = 0;
		}
		if(j%3 == 1){
			if(S.T[i-1][j-1].val > 0) S.T[i][j].p[(S.T[i-1][j-1].val)-1] = 0;
			if(S.T[i-2][j-1].val > 0) S.T[i][j].p[(S.T[i-2][j-1].val)-1] = 0;
			if(S.T[i-1][j+1].val > 0) S.T[i][j].p[(S.T[i-1][j+1].val)-1] = 0;
			if(S.T[i-2][j+1].val > 0) S.T[i][j].p[(S.T[i-2][j+1].val)-1] = 0;
		}
		if(j%3 == 2){
			if(S.T[i-1][j-1].val > 0) S.T[i][j].p[(S.T[i-1][j-1].val)-1] = 0;
			if(S.T[i-2][j-1].val > 0) S.T[i][j].p[(S.T[i-2][j-1].val)-1] = 0;
			if(S.T[i-1][j-2].val > 0) S.T[i][j].p[(S.T[i-1][j-2].val)-1] = 0;
			if(S.T[i-2][j-2].val > 0) S.T[i][j].p[(S.T[i-2][j-2].val)-1] = 0;
		}
	}
	
	return S;
}

SUDOKU tout_val_poss(SUDOKU S){
	int i,j;
	
	for(i=0;i<9;i++){
		for(j=0;j<9;j++){
		
		S = valeur_possible(S,i,j);
		
		}
	}
	
	return S;
}
SUDOKU init_sudoku(SUDOKU S){
	int i,j,e;
	
	for(i=0;i<9;i++){
		for(j=0;j<9;j++){
			
			for(e=0;e<9;e++){
				S.T[i][j].p[e] = e+1;
				
			}
		}
	}
	
	S = tout_val_poss(S);
	
	return S;
}

SUDOKU modifie_case(SUDOKU S, int i, int j){
	int val,t;
	val = S.T[i][j].val;
	
	
	//verifie que la case a modifié est bien une valeur de travail
	if(S.T[i][j].w == 1){ 
		
		// si la case est vide met la valeur possible supérieur la plus proche
		if(val == 0){
			for(t=0;t<9;t++){
				if(S.T[i][j].p[t] != 0){
					S.T[i][j].val = S.T[i][j].p[t];
					return S;
				}
			}
		}
		// si la valeur est 9 met la case a vide
		if(val == 9){
			S.T[i][j].val = 0;
			return S;
		}
		//si la case n'est pas vide cherche la valeur
		//possible supérieur la plus proche
		if(val > 0){   
			for(t=val;t<9;t++){
				if(S.T[i][j].p[t] != 0){
					S.T[i][j].val = S.T[i][j].p[t];
					return S;
				}
			}
			//si aucune des valeur supérieur n'est possible met la case a vide
			S.T[i][j].val = 0;
		}
	}
	return S;
}

SUDOKU modifie_case_inverse(SUDOKU S, int i, int j){
	int val,t;
	val = S.T[i][j].val;
	
		
	
	//verifie que la case a modifié est bien une valeur de travail
	if(S.T[i][j].w == 1){ 
		
		// si la case est vide met la valeur la plus haute possible 
		if(val == 0){
			for(t=8;t >= 0;t--){
				if(S.T[i][j].p[t] != 0){
					S.T[i][j].val = S.T[i][j].p[t];
					return S;
				}
			}
		}
		// si la valeur est 1 met la case a vide
		if(val == 1){
			S.T[i][j].val = 0;
			return S;
		}
		//si la case n'est pas vide cherche la valeur
		//possible inferieur la plus proche
		if(val > 1){   
			
			for(t=val-2;t >= 0;t--){
				if(S.T[i][j].p[t] != 0){
					S.T[i][j].val = S.T[i][j].p[t];
					return S;
				}
			}
			//si aucune des valeur inférieur n'est possible met la case a vide
			S.T[i][j].val = 0;
		}
	}
	return S;
}

int val_est_possible(SUDOKU S,int i, int j,int val){
	
	if(S.T[i][j].p[val-1] == 0) return 0;
	
	return 1;
}

int case_est_possible(SUDOKU S, int i, int j){
	int e,v;
	v = 0;
	for(e = 0; e < 9; e++){
		if(S.T[i][j].p[e] != 0) v++;
	}
	
	return v;
}


int sudoku_est_possible(SUDOKU S){
	int i,j;
	
	for(i = 0; i < 9; i++){
			for(j = 0; j < 9; j++){
				
				if(case_est_possible(S,i,j) == 0) return 0;
				
			}
		}
	return 1;
}

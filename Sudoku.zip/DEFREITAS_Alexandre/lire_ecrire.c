#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gestion_sudoku.h"


SUDOKU lire_fichier (char *nom) {
	SUDOKU S;
	int i,j,c,s;
	s = 0;
	i = 0;
	j = 0;
	FILE *F;
	F = fopen(nom,"r");
	
	S.nom = nom;
	if(F == NULL) {
		fprintf(stderr, "error opening file");
		exit(1);
	}
	while( c != EOF && j<=8) {
		c = fgetc(F);
		if(c != '\n'){
			//~ printf("#%d#\n",c);
			// ### VALEUR DE TRANSFORMÉ ###
			if(c == '*'){
				 c = fgetc(F);
				 S.T[i][j].w = 1;
				 
				 if(c == '1'){
				S.T[i][j].val = 1;
				}
				if(c == '2'){
					S.T[i][j].val = 2;
				}
				if(c == '3'){
					S.T[i][j].val = 3;
				}
				if(c == '4'){
					S.T[i][j].val = 4;
				}
				if(c == '5'){
					S.T[i][j].val = 5;
				}
				if(c == '6'){
					S.T[i][j].val = 6;
				}
				if(c == '7'){
					S.T[i][j].val = 7;
				}
				if(c == '8'){
					S.T[i][j].val = 8;
				}
				if(c == '9'){
					S.T[i][j].val = 9;
				}
		}
				// ### VALEUR DE DEPART ###
			else{
				
				if(c == '.'){ 
					S.T[i][j].val = 0;
					S.T[i][j].w = 1;
				}
				
				if(c == '1'){
					S.T[i][j].val = 1;
				}
				if(c == '2'){
					S.T[i][j].val = 2;
				}
				if(c == '3'){
					S.T[i][j].val = 3;
				}
				if(c == '4'){
					S.T[i][j].val = 4;
				}
				if(c == '5'){
					S.T[i][j].val = 5;
				}
				if(c == '6'){
					S.T[i][j].val = 6;
				}
				if(c == '7'){
					S.T[i][j].val = 7;
				}
				if(c == '8'){
					S.T[i][j].val = 8;
				}
				if(c == '9'){
					S.T[i][j].val = 9;
				}
			}
		
		if(j<9){
			if(i == 8){
				i = 0;
				j++;
			}
			else{ if(i<8) i++;}
			}
		}
	}
	while(nom[s] != '.') s++;
	if(nom[s+4]=='.'){
		S.num = ((nom[s+1]-'0')*100)+((nom[s+2]-'0')*10)+((nom[s+3]-'0')*1);
		printf("#%d#\n", S.num);
	}
	else {S.num = 0;}
	
	S = init_sudoku(S);
	fclose(F);
	return S;
}

void ecrire_fichier(SUDOKU* S) {
	
	SUDOKU H = *S;
	
	int s = 0;
	
	int i,j;
	//~ int d = 1;
	printf("%s\n" , H.nom);
	while((H.nom[s] != '.' )) { 
		s = s+1;
		
	}
	
	if(H.nom[s+4]!='.'){
		H.nom[s+1]  = '0';
		H.nom[s+2]  = '0';
		H.nom[s+3]  = '1';
	}
	else{
		H.num = H.num+1;
		if(H.num < 100) H.nom[s+1] = '0';
		else{H.nom[s+1] = H.num/100+'0';}
		H.num = H.num % 100;
		if(H.num < 10) H.nom[s+2] = '0';
		else{H.nom[s+2] = H.num/10+'0';}
		H.num = H.num % 10;
		H.nom[s+3] = H.num+'0';

	}
	H.nom[s+4]  = '.';
	H.nom[s+5]  = 's';
	H.nom[s+6]  = 'u';
	H.nom[s+7]  = 'd';
	H.nom[s+8]  = 'o';
	H.nom[s+9]  = 'k';
	H.nom[s+10] = 'u';
	H.nom[s+11] = '\0';
	
	
	
	
	printf("%s\n" , H.nom);
	
	FILE *F;
	F = fopen(H.nom,"w");
	
	if(F == NULL){
		fprintf(stderr, "error opening file");
		exit(1);
	}
	for(j=0;j<9;j++){
		for(i=0;i<9;i++){
			if(H.T[i][j].w == 0) fprintf(F,"%d",H.T[i][j].val);
			
			if(H.T[i][j].w == 1){
				if(H.T[i][j].val == 0) fprintf(F,".");
				if(H.T[i][j].val > 0) fprintf(F,"*%d", H.T[i][j].val);
				
			}
			if(i == 8)fprintf(F,"\n");
			//~ printf("#%d# %d\n",H.T[i][j].val,d);
			//~ d = d+1 ;
			
		}
	}
	fclose(F);
}


#include <stdio.h>
#include <uvsqgraphics.h>
#include "constantes.h"
#include "gestion_sudoku.h"

void initialiser_fenetre_graphique() {
	init_graphics(LARGEUR,HAUTEUR);
	affiche_auto_off();
}

void terminer_fenetre_graphique() {
	wait_escape();
}

void afficher_grille(){
	
	POINT p1,p2;
	int i;
	
	p1.x = 0; p1.y = 0;
	p2.x = TAILLE_CASE*9; p2.y = TAILLE_CASE*9;
	draw_rectangle(p1,p2,COUL_TRAIT);
	
	for(i=0;i<9;i++){
		
		p1.x = TAILLE_CASE*i; p1.y = 0;
		p2.x = p1.x; p2.y = TAILLE_CASE*9;
		draw_line(p1,p2,COUL_TRAIT);
	}
	for(i=0;i<9;i++){
		p1.x = 0; p1.y = TAILLE_CASE*i;
		p2.x = TAILLE_CASE*9; p2.y = p1.y;
		draw_line(p1,p2,COUL_TRAIT);
	}
	
	
}


void afficher_region(){
	int i;
	POINT p1,p2;
	
	for(i=0;i<10;i = i+3){
		p1.x = 0; p1.y = TAILLE_CASE*i+1;
		p2.x = TAILLE_CASE*9; p2.y = p1.y;
		draw_line(p1,p2,COUL_TRAIT);
	
		p1.x = 0; p1.y = TAILLE_CASE*i-1;
		p2.x = TAILLE_CASE*9; p2.y = p1.y;
		draw_line(p1,p2,COUL_TRAIT);
	}
	for(i=0;i<10;i = i+3){
		p1.x = TAILLE_CASE*i+1; p1.y = 0;
		p2.x = p1.x; p2.y = TAILLE_CASE*9;
		draw_line(p1,p2,COUL_TRAIT);
		
		p1.x = TAILLE_CASE*i-1; p1.y = 0;
		p2.x = p1.x; p2.y = TAILLE_CASE*9;
		draw_line(p1,p2,COUL_TRAIT);
	}
}

void afficher_titre(SUDOKU S){
	
	POINT p;
	
	p.x = 5; p.y = TAILLE_CASE*10 ;
	
	aff_pol(S.nom, TAILLE_POLICE,p,COUL_TITRE);
	
}

void afficher_nbres(SUDOKU S){
	
	int i,j;
	
	POINT p;
	for(j=0;j<9;j++){
		for(i=0;i<9;i++){
			
			p.x = (TAILLE_CASE*i)+25;
			p.y = ((TAILLE_CASE*9)-(TAILLE_CASE*j));
			if( S.T[i][j].w == 0 && S.T[i][j].val >0 && S.T[i][j].val <= 9){
				
				aff_int(S.T[i][j].val,TAILLE_POLICE,p,COUL_VAL_DEPART);
			}
			if(S.T[i][j].w == 1 && S.T[i][j].val == 0);
			
			
			
			if(S.T[i][j].w == 1 && S.T[i][j].val >0 && S.T[i][j].val <= 9){
				aff_int(S.T[i][j].val,TAILLE_POLICE,p,COUL_VAL_TRAVAIL);
			}
			if(S.T[i][j].w == 2 && S.T[i][j].val >0 && S.T[i][j].val <= 9){
				aff_int(S.T[i][j].val,TAILLE_POLICE,p,COUL_VAL_RES);
			}
		}
		
	}
}

void afficher_poss(SUDOKU S){
	
	int i,j,e,valp;
	POINT p;
	for(j=0;j<9;j++){
		for(i=0;i<9;i++){
			if(S.T[i][j].w == 1){
				for(e=0;e<9;e++){
					if(S.T[i][j].p[e] >0){
						valp = S.T[i][j].p[e];
						p.x = (TAILLE_CASE*i)+5+(e*10);
						p.y = ((TAILLE_CASE*9)-(TAILLE_CASE*j));
						aff_int(valp,TAILLE_POLICE/5,p,COUL_VAL_TRAVAIL);
						
					}
				}
			}
		}
	}
}

void afficher_win(){
	POINT p;
	fill_screen(COUL_FOND);
	p.x = 1*TAILLE_CASE; p.y = 2*HAUTEUR/3;
	aff_pol(" Vous avez gagner !", TAILLE_POLICE,p,COUL_TITRE);
	affiche_all();
	
}


void sudoku_afficher(SUDOKU S) {
	fill_screen(COUL_FOND);
	afficher_titre(S);
	afficher_grille();
	afficher_region();
	afficher_poss(S);
	afficher_nbres(S);
	//~ wait_clic();
	affiche_all();
}
